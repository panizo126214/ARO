package com.aro.stailishapp;

import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.ListView;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.aro.stailishapp.databinding.ActivityPromptBinding;

import java.util.ArrayList;

import Model.Mensaje;
import Model.MensajeAdapter;

public class PromptActivity extends AppCompatActivity {

    private AppBarConfiguration appBarConfiguration;
    private ActivityPromptBinding binding;

    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_prompt);

        listView = findViewById(R.id.lvMensajes);

        ArrayList<Mensaje> arrayList = new ArrayList<>();

        arrayList.add(new Mensaje("Gato cool 1","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQt0OtDMpDHvww7uM2YnAXGO2dy1fUxvRidfpubV9JZ4w&s"));

        MensajeAdapter mensajeAdapter = new MensajeAdapter(this,R.layout.list_row,arrayList);
        listView.setAdapter(mensajeAdapter);
    }
}