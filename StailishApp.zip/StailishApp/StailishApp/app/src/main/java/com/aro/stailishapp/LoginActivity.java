package com.aro.stailishapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import API.ApiInterface;
import API.ServiceGenerator;
import Model.Usuario;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        EditText etUsuario = findViewById(R.id.etUsuarioLogin);
        EditText etContrasena = findViewById(R.id.etContrasenaLogin);
        TextView tvLoginRes = findViewById(R.id.tvResLogin);

        Button btnReg = findViewById(R.id.btnRegLogin);
        btnReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Intent intent = new Intent(LoginActivity.this,RegisterActivity.class);
                //startActivity(intent);
                Intent intent = new Intent(LoginActivity.this,PromptActivity.class);
                startActivity(intent);
            }
        });


        Button btn = findViewById(R.id.btnIniciarSesion);
        btn.setOnClickListener(new View.OnClickListener() {
            ApiInterface apiInterface = ServiceGenerator.createService(ApiInterface.class);
            @Override
            public void onClick(View view) {
                String usuario = etUsuario.getText().toString();
                String contraseña = etContrasena.getText().toString();
                Call<Integer> call = apiInterface.login(usuario,contraseña);
                call.enqueue(new Callback<Integer>() {
                    @Override
                    public void onResponse(Call<Integer> call, Response<Integer> response) {

                        tvLoginRes.setText(response.body().toString()+usuario+contraseña);

                        if (response.body() == 1) {
                            Toast.makeText(getApplicationContext(), "Bienvenido!",Toast.LENGTH_LONG);
                            Intent intent = new Intent(LoginActivity.this,ChatActivity.class);
                            startActivity(intent);
                        }
                        else{
                            Toast.makeText(getApplicationContext(), "Credenciales no correctas.",Toast.LENGTH_LONG);
                        }
                    }

                    @Override
                    public void onFailure(Call<Integer> call, Throwable t) {
                        //ha fallado mostrar aviso de que es posible de que no tenga intertet
                        Log.e("tag", t.getMessage());
                    }
                });
            }
        });
    }
}