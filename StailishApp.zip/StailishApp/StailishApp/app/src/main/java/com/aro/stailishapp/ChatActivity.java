package com.aro.stailishapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.Toast;

import API.ApiInterface;
import API.ServiceGenerator;
import Model.Pregunta;
import Model.Respuesta;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ChatActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        Button btnSend = findViewById(R.id.btnEnviar);
        EditText etPrompt = findViewById(R.id.txtMensaje);
        //RecyclerView recycler = findViewById(R.id.rvMensajes);

        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                ApiInterface apiInterface = ServiceGenerator.createService(ApiInterface.class);
                String prompt = etPrompt.getText().toString();
                Pregunta request = new Pregunta(prompt);
                Call<Respuesta> call = apiInterface.generateImageByPrompt(request);
                call.enqueue(new Callback<Respuesta>() {
                    @Override
                    public void onResponse(Call<Respuesta> call, Response<Respuesta> response) {



                    }

                    @Override
                    public void onFailure(Call<Respuesta> call, Throwable t) {
                        //ha fallado mostrar aviso de que es posible de que no tenga intertet
                        Log.e("tag", t.getMessage());
                    }
                });
            }
        });

    }
}