package Model;

public class Pregunta {

    public String key;
    public String prompt;
    public String negative_prompt;
    public String width;
    public String height;
    public String samples;
    public String num_inference_steps;
    public Object seed;
    public double guidance_scale;
    public String safety_checker;
    public Object webhook;
    public Object track_id;

    public Pregunta(String prompt) {
        this.prompt = prompt;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getPrompt() {
        return prompt;
    }

    public void setPrompt(String prompt) {
        this.prompt = prompt;
    }

    public String getNegative_prompt() {
        return negative_prompt;
    }

    public void setNegative_prompt(String negative_prompt) {
        this.negative_prompt = negative_prompt;
    }

    public String getWidth() {
        return width;
    }

    public void setWidth(String width) {
        this.width = width;
    }

    public String getHeight() {
        return height;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public String getSamples() {
        return samples;
    }

    public void setSamples(String samples) {
        this.samples = samples;
    }

    public String getNum_inference_steps() {
        return num_inference_steps;
    }

    public void setNum_inference_steps(String num_inference_steps) {
        this.num_inference_steps = num_inference_steps;
    }

    public Object getSeed() {
        return seed;
    }

    public void setSeed(Object seed) {
        this.seed = seed;
    }

    public double getGuidance_scale() {
        return guidance_scale;
    }

    public void setGuidance_scale(double guidance_scale) {
        this.guidance_scale = guidance_scale;
    }

    public String getSafety_checker() {
        return safety_checker;
    }

    public void setSafety_checker(String safety_checker) {
        this.safety_checker = safety_checker;
    }

    public Object getWebhook() {
        return webhook;
    }

    public void setWebhook(Object webhook) {
        this.webhook = webhook;
    }

    public Object getTrack_id() {
        return track_id;
    }

    public void setTrack_id(Object track_id) {
        this.track_id = track_id;
    }
}


