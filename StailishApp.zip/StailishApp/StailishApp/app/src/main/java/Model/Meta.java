package Model;

public class Meta{
    public int h;
    public int w;
    public String enable_attention_slicing;
    public String file_prefix;
    public double guidance_scale;
    public String model;
    public int n_samples;
    public String negative_prompt;
    public String outdir;
    public String prompt;
    public String revision;
    public String safety_checker;
    public int seed;
    public int steps;
    public String vae;
}