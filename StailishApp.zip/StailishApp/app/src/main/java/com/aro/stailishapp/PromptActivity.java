package com.aro.stailishapp;

import android.annotation.SuppressLint;
import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.util.ArrayMap;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.aro.stailishapp.databinding.ActivityPromptBinding;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Map;

import API.ApiInterface;
import API.ServiceGenerator;
import Model.Mensaje;
import Model.MensajeAdapter;
import Model.Pregunta;
import Model.Respuesta;
import Model.RespuestaImagen;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.http.Body;
import retrofit2.http.POST;

public class PromptActivity extends AppCompatActivity {

    private AppBarConfiguration appBarConfiguration;
    private ActivityPromptBinding binding;

    ListView listView;
    EditText etEditPrompt;
    Button btnSendPrompt;
    TextView tvResponse;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_prompt);

        listView = findViewById(R.id.lvMensajes);
        etEditPrompt = findViewById(R.id.etEditPrompt);
        btnSendPrompt = findViewById(R.id.btnSendPrompt);
        tvResponse = findViewById(R.id.tvRespuestaPrompt);

        ArrayList<Mensaje> arrayList = new ArrayList<>();


        btnSendPrompt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String prompt = etEditPrompt.getText().toString();
                ApiInterface apiInterface = ServiceGenerator.createService(ApiInterface.class);
                Pregunta request = new Pregunta(prompt);
                Call<Respuesta> call = apiInterface.generateImageByPrompt(request);
                call.enqueue(new Callback<Respuesta>() {
                    @Override
                    public void onResponse(Call<Respuesta> call, Response<Respuesta> response) {


                        //response.wait();
                        Respuesta resp = response.body();
                        ArrayList<String> link_img = response.body().getOutput();
                        String img = link_img.get(0);
                        tvResponse.setText(img);

                        arrayList.add(new Mensaje(prompt,img));
                        MensajeAdapter mensajeAdapter = new MensajeAdapter(getBaseContext(),R.layout.list_row,arrayList);
                        listView.setAdapter(mensajeAdapter);
                        //try {
                        //    Thread.sleep(65 * 1000);
                        //} catch (InterruptedException e) {
                        //    e.printStackTrace();
                        //}

                        //Call<RespuestaImagen> callImagen = apiInterface.getFinalImage(link,"w9hNaEocVj1CSx4sFhg4xxk911Qde5sczCIqmLLQwnGMfWt7zoy9V3WZs6ws");

                    }

                    @Override
                    public void onFailure(Call<Respuesta> call, Throwable t) {
                        //ha fallado mostrar aviso de que es posible de que no tenga intertet
                        Log.e("tag", t.getMessage());
                    }
                });
            }
        });

        arrayList.add(new Mensaje("Gato cool 1","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQt0OtDMpDHvww7uM2YnAXGO2dy1fUxvRidfpubV9JZ4w&s"));
        //arrayList.add(new Mensaje("Gato cool 1","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQt0OtDMpDHvww7uM2YnAXGO2dy1fUxvRidfpubV9JZ4w&s"));
        //arrayList.add(new Mensaje("Gato cool 1","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQt0OtDMpDHvww7uM2YnAXGO2dy1fUxvRidfpubV9JZ4w&s"));
        //arrayList.add(new Mensaje("Gato cool 1","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQt0OtDMpDHvww7uM2YnAXGO2dy1fUxvRidfpubV9JZ4w&s"));
        //arrayList.add(new Mensaje("Gato cool 1","https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQt0OtDMpDHvww7uM2YnAXGO2dy1fUxvRidfpubV9JZ4w&s"));

        MensajeAdapter mensajeAdapter = new MensajeAdapter(this,R.layout.list_row,arrayList);
        listView.setAdapter(mensajeAdapter);
    }
}