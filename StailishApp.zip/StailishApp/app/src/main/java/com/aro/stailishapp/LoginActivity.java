package com.aro.stailishapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.util.List;

import API.ApiInterface;
import Model.Usuario;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Button btn = findViewById(R.id.btnIniciarSesion);
        btn.setOnClickListener(new View.OnClickListener() {
            ApiInterface apiInterface = new ApiInterface() {
                @Override
                public Call<List<Usuario>> getUsuarios() {
                    return null;
                }

                @Override
                public Call<List<Usuario>> getUsuario(String codigo) {
                    return null;
                }
            };

            @Override
            public void onClick(View view) {
                Call<List<Usuario>> call = apiInterface.getUsuario("00111111");
                call.enqueue(new Callback<List<Usuario>>() {
                    @Override
                    public void onResponse(Call<List<Usuario>> call, Response<List<Usuario>> response) {
                        if (response.isSuccessful()) {
                            for (Usuario usu : response.body()) {
                                System.out.println("usuario: " + usu.getNombre());
                            }
                        }
                    }

                    @Override
                    public void onFailure(Call<List<Usuario>> call, Throwable t) {
                        //ha fallado mostrar aviso de que es posible de que no tenga intertet
                        Log.e("tag", t.getMessage());
                    }
                });
            }
        });
    }
}