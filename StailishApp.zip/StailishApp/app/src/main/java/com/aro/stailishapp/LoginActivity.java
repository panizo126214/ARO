package com.aro.stailishapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.util.List;

import API.ApiInterface;
import API.ServiceGenerator;
import Model.Usuario;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Button btnReg = findViewById(R.id.btnRegLogin);
        btnReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this,RegisterActivity.class);
                startActivity(intent);
            }
        });


        Button btn = findViewById(R.id.btnIniciarSesion);
        btn.setOnClickListener(new View.OnClickListener() {
            ApiInterface apiInterface = ServiceGenerator.createService(ApiInterface.class);
            @Override
            public void onClick(View view) {
                Call<List<Usuario>> call = apiInterface.getUsuario("00111111");
                call.enqueue(new Callback<List<Usuario>>() {
                    @Override
                    public void onResponse(Call<List<Usuario>> call, Response<List<Usuario>> response) {
                        if (response.isSuccessful()) {
                            for (Usuario usu : response.body()) {
                                System.out.println("usuario: " + usu.getNombre());
                            }
                        }
                    }

                    @Override
                    public void onFailure(Call<List<Usuario>> call, Throwable t) {
                        //ha fallado mostrar aviso de que es posible de que no tenga intertet
                        Log.e("tag", t.getMessage());
                    }
                });
            }
        });
    }
}