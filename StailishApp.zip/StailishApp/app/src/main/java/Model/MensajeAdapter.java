package Model;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.aro.stailishapp.R;
import com.squareup.picasso.Picasso;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class MensajeAdapter extends ArrayAdapter<Mensaje> {

    private Context mContext;
    private int mResource;
    public MensajeAdapter(@NonNull Context context, int resource, @NonNull ArrayList<Mensaje> objects) {
        super(context, resource, objects);

        this.mContext = context;
        this.mResource = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        LayoutInflater layoutInflater = LayoutInflater.from(mContext);
        convertView = layoutInflater.inflate(mResource,parent,false);

        ImageView imageView = convertView.findViewById(R.id.ivImagenMensajePrompt);
        TextView textView = convertView.findViewById(R.id.tvTextoMensajePrompt);

        Mensaje m = getItem(position);

        //InputStream in = null;
        //try {
        //    in = new java.net.URL(m.getImg_src()).openStream();
        //} catch (IOException e) {
        //    e.printStackTrace();
        //}
        //Bitmap image = BitmapFactory.decodeStream(in);

        Picasso.with(getContext()).load(m.getImg_src()).into(imageView);
        //imageView.setImageBitmap(image);

        textView.setText(m.getPrompt());
        return convertView;
    }
}
